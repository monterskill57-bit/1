import {Composition,Still,Sequence,AbsoluteFill,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {Shot,Brand,WordCaptions,Accent,Planning,EndCard,Cover} from './Design';
import {pages1} from './Captions1';
import {pages2} from './Captions2';
export const Part1=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:"#17201b"}}>
<Sequence name="План 1 / 1.mp4" from={0} durationInFrames={102} premountFor={fps}><Shot src="1.mp4" trim={6} still={false} zoom={1.0} position="35% 50%"/></Sequence>
<Sequence name="План 2 / 3.mp4" from={102} durationInFrames={96} premountFor={fps}><Shot src="3.mp4" trim={9} still={false} zoom={1.05} position="25% 50%"/></Sequence>
<Sequence name="План 3 / 2.mp4" from={198} durationInFrames={126} premountFor={fps}><Shot src="2.mp4" trim={0} still={false} zoom={1.0} position="25% 50%"/></Sequence>
<Sequence name="План 4 / 1.mp4" from={324} durationInFrames={96} premountFor={fps}><Shot src="1.mp4" trim={90} still={false} zoom={1.12} position="65% 45%"/></Sequence>
<Sequence name="План 5 / wood.jpg" from={420} durationInFrames={90} premountFor={fps}><Shot src="wood.jpg" trim={0} still={true} zoom={1.32} position="0% 38%"/></Sequence>
<Sequence name="План 6 / 2.mp4" from={510} durationInFrames={99} premountFor={fps}><Shot src="2.mp4" trim={24} still={false} zoom={1.04} position="30% 50%"/></Sequence>
<Sequence name="План 7 / 4.mp4" from={609} durationInFrames={78} premountFor={fps}><Shot src="4.mp4" trim={0} still={false} zoom={1.02} position="40% 45%"/></Sequence>
<Sequence name="План 8 / 3.mp4" from={687} durationInFrames={93} premountFor={fps}><Shot src="3.mp4" trim={102} still={false} zoom={1.08} position="10% 42%"/></Sequence>
<Sequence name="План 9 / 1.mp4" from={780} durationInFrames={90} premountFor={fps}><Shot src="1.mp4" trim={138} still={false} zoom={1.13} position="60% 45%"/></Sequence>
<Sequence name="План 10 / front.jpg" from={870} durationInFrames={132} premountFor={fps}><Shot src="front.jpg" trim={0} still={true} zoom={1.13} position="18% 45%"/></Sequence>
<Sequence name="План 11 / 3.mp4" from={1002} durationInFrames={93} premountFor={fps}><Shot src="3.mp4" trim={18} still={false} zoom={1.23} position="0% 38%"/></Sequence>
<Sequence name="План 12 / 1.mp4" from={1095} durationInFrames={132} premountFor={fps}><Shot src="1.mp4" trim={54} still={false} zoom={1.07} position="38% 45%"/></Sequence>
<Sequence name="План 13 / house.jpg" from={1227} durationInFrames={78} premountFor={fps}><Shot src="house.jpg" trim={0} still={true} zoom={1.08} position="40% 45%"/></Sequence>
<Brand part={1} duration={1305}/><Audio src={staticFile("part1.wav")} premountFor={fps}/>
<Sequence name="СЕНТЯБРЬ / ОКТЯБРЬ / Почему мы не красим фасады осенью?" from={0} durationInFrames={156} premountFor={fps}><Accent eyebrow="СЕНТЯБРЬ / ОКТЯБРЬ" title={"Почему мы\nне красим фасады\nосенью?"} kind="hero"/></Sequence>
<Sequence name="ПРИЧИНА / Нестабильная погода" from={332} durationInFrames={94} premountFor={fps}><Accent eyebrow="ПРИЧИНА" title={"Нестабильная\nпогода"}/></Sequence>
<Sequence name="ДНЁМ / +15 °C" from={615} durationInFrames={24} premountFor={fps}><Accent eyebrow="ДНЁМ" title={"+15 °C"} kind="temperature"/></Sequence>
<Sequence name="ДНЁМ / +20 °C" from={639} durationInFrames={24} premountFor={fps}><Accent eyebrow="ДНЁМ" title={"+20 °C"} kind="temperature"/></Sequence>
<Sequence name="ДНЁМ / +18 °C" from={663} durationInFrames={29} premountFor={fps}><Accent eyebrow="ДНЁМ" title={"+18 °C"} kind="temperature"/></Sequence>
<Sequence name="НОЧЬЮ / ТОЧКА РОСЫ" from={695} durationInFrames={77} premountFor={fps}><Accent eyebrow="НОЧЬЮ" title={"ТОЧКА РОСЫ"}/></Sequence>
<Sequence name="НОЧЬЮ / ТУМАН" from={774} durationInFrames={60} premountFor={fps}><Accent eyebrow="НОЧЬЮ" title={"ТУМАН"} subtitle={"Высокая вероятность"}/></Sequence>
<Sequence name="НОЧЬЮ / ДО 0 °C" from={840} durationInFrames={166} premountFor={fps}><Accent eyebrow="НОЧЬЮ" title={"ДО 0 °C"} subtitle={"Возможно резкое похолодание"}/></Sequence>
<Sequence name="НЕПОДХОДЯЩИЕ УСЛОВИЯ / РИСК ДЛЯ КАЧЕСТВА ПОКРЫТИЯ" from={1037} durationInFrames={187} premountFor={fps}><Accent eyebrow="НЕПОДХОДЯЩИЕ УСЛОВИЯ" title={"РИСК ДЛЯ\nКАЧЕСТВА\nПОКРЫТИЯ"}/></Sequence>
<WordCaptions pages={pages1}/>
<Sequence name="Финальная карточка" from={1227} durationInFrames={78} premountFor={fps}><EndCard part={1}/></Sequence>
</AbsoluteFill>};
export const Part2=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:"#17201b"}}>
<Sequence name="План 1 / 3.mp4" from={0} durationInFrames={102} premountFor={fps}><Shot src="3.mp4" trim={72} still={false} zoom={1.04} position="25% 45%"/></Sequence>
<Sequence name="План 2 / 1.mp4" from={102} durationInFrames={102} premountFor={fps}><Shot src="1.mp4" trim={9} still={false} zoom={1.09} position="42% 45%"/></Sequence>
<Sequence name="План 3 / wood.jpg" from={204} durationInFrames={105} premountFor={fps}><Shot src="wood.jpg" trim={0} still={true} zoom={1.18} position="0% 45%"/></Sequence>
<Sequence name="План 4 / 2.mp4" from={309} durationInFrames={99} premountFor={fps}><Shot src="2.mp4" trim={9} still={false} zoom={1.04} position="28% 45%"/></Sequence>
<Sequence name="План 5 / 3.mp4" from={408} durationInFrames={102} premountFor={fps}><Shot src="3.mp4" trim={96} still={false} zoom={1.1} position="10% 43%"/></Sequence>
<Sequence name="План 6 / 1.mp4" from={510} durationInFrames={114} premountFor={fps}><Shot src="1.mp4" trim={114} still={false} zoom={1.04} position="64% 45%"/></Sequence>
<Sequence name="План 7 / 4.mp4" from={624} durationInFrames={96} premountFor={fps}><Shot src="4.mp4" trim={0} still={false} zoom={1.13} position="35% 44%"/></Sequence>
<Sequence name="План 8 / front.jpg" from={720} durationInFrames={111} premountFor={fps}><Shot src="front.jpg" trim={0} still={true} zoom={1.05} position="25% 45%"/></Sequence>
<Sequence name="План 9 / 3.mp4" from={831} durationInFrames={99} premountFor={fps}><Shot src="3.mp4" trim={39} still={false} zoom={1.25} position="0% 40%"/></Sequence>
<Sequence name="План 10 / 1.mp4" from={930} durationInFrames={105} premountFor={fps}><Shot src="1.mp4" trim={18} still={false} zoom={1.05} position="40% 45%"/></Sequence>
<Sequence name="План 11 / wood.jpg" from={1035} durationInFrames={93} premountFor={fps}><Shot src="wood.jpg" trim={0} still={true} zoom={1.33} position="0% 38%"/></Sequence>
<Sequence name="План 12 / 2.mp4" from={1128} durationInFrames={90} premountFor={fps}><Shot src="2.mp4" trim={3} still={false} zoom={1.07} position="30% 45%"/></Sequence>
<Sequence name="План 13 / house.jpg" from={1218} durationInFrames={99} premountFor={fps}><Shot src="house.jpg" trim={0} still={true} zoom={1.12} position="35% 45%"/></Sequence>
<Brand part={2} duration={1317}/><Audio src={staticFile("part2.wav")} premountFor={fps}/>
<Sequence name="ПРОДОЛЖЕНИЕ / ЧАСТЬ 2 / ФАСАДНЫЕ РАБОТЫ ОСЕНЬЮ" from={0} durationInFrames={108} premountFor={fps}><Accent eyebrow="ПРОДОЛЖЕНИЕ / ЧАСТЬ 2" title={"ФАСАДНЫЕ\nРАБОТЫ ОСЕНЬЮ"}/></Sequence>
<Sequence name="СОВЕТ ЗАКАЗЧИКАМ / ПЛАНИРУЙТЕ ЗАРАНЕЕ" from={576} durationInFrames={84} premountFor={fps}><Accent eyebrow="СОВЕТ ЗАКАЗЧИКАМ" title={"ПЛАНИРУЙТЕ\nЗАРАНЕЕ"}/></Sequence>
<Sequence name="КОНЕЦ АВГУСТА / «А НАДО БЫ ФАСАД ПОКРАСИТЬ…»" from={692} durationInFrames={151} premountFor={fps}><Accent eyebrow="КОНЕЦ АВГУСТА" title={"«А НАДО БЫ\nФАСАД\nПОКРАСИТЬ…»"}/></Sequence>
<Sequence name="СЕНТЯБРЬ / ОКТЯБРЬ / КАЧЕСТВО ПОД ВОПРОСОМ" from={1026} durationInFrames={172} premountFor={fps}><Accent eyebrow="СЕНТЯБРЬ / ОКТЯБРЬ" title={"КАЧЕСТВО\nПОД ВОПРОСОМ"}/></Sequence>
<Sequence name="Этапы планирования" from={177} durationInFrames={173} premountFor={fps}><Planning/></Sequence>
<WordCaptions pages={pages2}/>
<Sequence name="Финальная карточка" from={1218} durationInFrames={99} premountFor={fps}><EndCard part={2}/></Sequence>
</AbsoluteFill>};
export const Root=()=> <>
<Composition id="Part1" component={Part1} width={1080} height={1920} fps={30} durationInFrames={1305}/>
<Composition id="Part2" component={Part2} width={1080} height={1920} fps={30} durationInFrames={1317}/>
<Still id="Cover1" component={Cover} width={1080} height={1920} defaultProps={{part:1}}/>
<Still id="Cover2" component={Cover} width={1080} height={1920} defaultProps={{part:2}}/>
</>;
