import type {Page} from './Design';
export const pages1:Page[]=[
  {
    "start": 250,
    "end": 2670,
    "words": [
      {
        "text": " Сегодня",
        "startMs": 250,
        "endMs": 490,
        "timestampMs": 370,
        "confidence": 0.8887957334518433
      },
      {
        "text": " хотела",
        "startMs": 490,
        "endMs": 870,
        "timestampMs": 680,
        "confidence": 0.9256819486618042
      },
      {
        "text": " бы",
        "startMs": 870,
        "endMs": 1170,
        "timestampMs": 1020,
        "confidence": 0.9879542589187622
      },
      {
        "text": " прояснить",
        "startMs": 1170,
        "endMs": 2050,
        "timestampMs": 1610,
        "confidence": 0.8796348174413046
      },
      {
        "text": " ситуацию,",
        "startMs": 2050,
        "endMs": 2530,
        "timestampMs": 2290,
        "confidence": 0.9819199442863464
      }
    ]
  },
  {
    "start": 2670,
    "end": 5470,
    "words": [
      {
        "text": " почему",
        "startMs": 2670,
        "endMs": 2850,
        "timestampMs": 2760,
        "confidence": 0.9867182374000549
      },
      {
        "text": " мы",
        "startMs": 2850,
        "endMs": 3050,
        "timestampMs": 2950,
        "confidence": 0.9960727691650391
      },
      {
        "text": " отказываем",
        "startMs": 3050,
        "endMs": 3670,
        "timestampMs": 3360,
        "confidence": 0.9909740885098776
      },
      {
        "text": " нашим",
        "startMs": 3670,
        "endMs": 4130,
        "timestampMs": 3900,
        "confidence": 0.8862323462963104
      },
      {
        "text": " клиентам",
        "startMs": 4130,
        "endMs": 4810,
        "timestampMs": 4470,
        "confidence": 0.99564661582311
      },
      {
        "text": " в",
        "startMs": 5070,
        "endMs": 5470,
        "timestampMs": 5270,
        "confidence": 0.8755743503570557
      }
    ]
  },
  {
    "start": 5470,
    "end": 8370,
    "words": [
      {
        "text": " фасадных",
        "startMs": 5470,
        "endMs": 5890,
        "timestampMs": 5680,
        "confidence": 0.9490584582090378
      },
      {
        "text": " работах",
        "startMs": 5890,
        "endMs": 6550,
        "timestampMs": 6220,
        "confidence": 0.9978883266448975
      },
      {
        "text": " по",
        "startMs": 6550,
        "endMs": 6910,
        "timestampMs": 6730,
        "confidence": 0.9735192656517029
      },
      {
        "text": " срубам",
        "startMs": 6910,
        "endMs": 7690,
        "timestampMs": 7300,
        "confidence": 0.9388498216867447
      },
      {
        "text": " и",
        "startMs": 7690,
        "endMs": 7910,
        "timestampMs": 7800,
        "confidence": 0.9672771096229553
      },
      {
        "text": " клеёному",
        "startMs": 7910,
        "endMs": 8370,
        "timestampMs": 8140,
        "confidence": 0.2814226526534185
      }
    ]
  },
  {
    "start": 8370,
    "end": 9970,
    "words": [
      {
        "text": " брусу",
        "startMs": 8370,
        "endMs": 8830,
        "timestampMs": 8600,
        "confidence": 0.8060168549418449
      },
      {
        "text": " в",
        "startMs": 8830,
        "endMs": 9170,
        "timestampMs": 9000,
        "confidence": 0.5986480712890625
      },
      {
        "text": " сентябре",
        "startMs": 9170,
        "endMs": 9530,
        "timestampMs": 9350,
        "confidence": 0.9835778594017028
      },
      {
        "text": " и",
        "startMs": 9530,
        "endMs": 9670,
        "timestampMs": 9600,
        "confidence": 0.7795925736427307
      },
      {
        "text": " в",
        "startMs": 9670,
        "endMs": 9710,
        "timestampMs": 9690,
        "confidence": 0.7265660762786865
      },
      {
        "text": " октябре",
        "startMs": 9710,
        "endMs": 9970,
        "timestampMs": 9840,
        "confidence": 0.968575581908226
      }
    ]
  },
  {
    "start": 9970,
    "end": 10690,
    "words": [
      {
        "text": " месяце.",
        "startMs": 9970,
        "endMs": 10530,
        "timestampMs": 10250,
        "confidence": 0.8270751535892487
      }
    ]
  },
  {
    "start": 11070,
    "end": 12210,
    "words": [
      {
        "text": " Причина",
        "startMs": 11070,
        "endMs": 11510,
        "timestampMs": 11290,
        "confidence": 0.9740108052889506
      },
      {
        "text": " простая.",
        "startMs": 11510,
        "endMs": 12050,
        "timestampMs": 11780,
        "confidence": 0.6088623702526093
      }
    ]
  },
  {
    "start": 12570,
    "end": 15130,
    "words": [
      {
        "text": " Атмосфера",
        "startMs": 12570,
        "endMs": 13070,
        "timestampMs": 12820,
        "confidence": 0.9470163226127625
      },
      {
        "text": " нестабильна,",
        "startMs": 13070,
        "endMs": 13890,
        "timestampMs": 13480,
        "confidence": 0.8977068781852722
      },
      {
        "text": " даже",
        "startMs": 13910,
        "endMs": 14110,
        "timestampMs": 14010,
        "confidence": 0.9835458993911743
      },
      {
        "text": " несмотря",
        "startMs": 14110,
        "endMs": 14510,
        "timestampMs": 14310,
        "confidence": 0.945805013179779
      },
      {
        "text": " на",
        "startMs": 14510,
        "endMs": 14790,
        "timestampMs": 14650,
        "confidence": 0.9982841610908508
      },
      {
        "text": " то,",
        "startMs": 14790,
        "endMs": 14970,
        "timestampMs": 14880,
        "confidence": 0.9994981288909912
      }
    ]
  },
  {
    "start": 15190,
    "end": 18270,
    "words": [
      {
        "text": " что",
        "startMs": 15190,
        "endMs": 15370,
        "timestampMs": 15280,
        "confidence": 0.9986076951026917
      },
      {
        "text": " сентябрь",
        "startMs": 15370,
        "endMs": 17210,
        "timestampMs": 16290,
        "confidence": 0.8944006323814392
      },
      {
        "text": " и",
        "startMs": 17210,
        "endMs": 17330,
        "timestampMs": 17270,
        "confidence": 0.9629616141319275
      },
      {
        "text": " октябрь",
        "startMs": 17330,
        "endMs": 17750,
        "timestampMs": 17540,
        "confidence": 0.9730088263750076
      },
      {
        "text": " может",
        "startMs": 17750,
        "endMs": 17970,
        "timestampMs": 17860,
        "confidence": 0.8068627119064331
      },
      {
        "text": " быть",
        "startMs": 17970,
        "endMs": 18270,
        "timestampMs": 18120,
        "confidence": 0.9989297986030579
      }
    ]
  },
  {
    "start": 18270,
    "end": 20110,
    "words": [
      {
        "text": " тёплым",
        "startMs": 18270,
        "endMs": 18670,
        "timestampMs": 18470,
        "confidence": 0.7383549988269806
      },
      {
        "text": " месяцем,",
        "startMs": 18670,
        "endMs": 19290,
        "timestampMs": 18980,
        "confidence": 0.9249545931816101
      },
      {
        "text": " днём,",
        "startMs": 19490,
        "endMs": 19950,
        "timestampMs": 19720,
        "confidence": 0.9570680459340414
      }
    ]
  },
  {
    "start": 20170,
    "end": 21170,
    "words": [
      {
        "text": " да,",
        "startMs": 20170,
        "endMs": 20250,
        "timestampMs": 20210,
        "confidence": 0.5469855070114136
      },
      {
        "text": " плюс",
        "startMs": 20490,
        "endMs": 20610,
        "timestampMs": 20550,
        "confidence": 0.8090814352035522
      },
      {
        "text": " 15,",
        "startMs": 20610,
        "endMs": 21010,
        "timestampMs": 20810,
        "confidence": 0.8929805159568787
      }
    ]
  },
  {
    "start": 21310,
    "end": 22850,
    "words": [
      {
        "text": " плюс",
        "startMs": 21310,
        "endMs": 21490,
        "timestampMs": 21400,
        "confidence": 0.9177766442298889
      },
      {
        "text": " 20,",
        "startMs": 21490,
        "endMs": 21890,
        "timestampMs": 21690,
        "confidence": 0.9918251037597656
      },
      {
        "text": " плюс",
        "startMs": 22090,
        "endMs": 22250,
        "timestampMs": 22170,
        "confidence": 0.9810543060302734
      },
      {
        "text": " 18.",
        "startMs": 22250,
        "endMs": 22690,
        "timestampMs": 22470,
        "confidence": 0.9929608702659607
      }
    ]
  },
  {
    "start": 23170,
    "end": 25490,
    "words": [
      {
        "text": " Ночью",
        "startMs": 23170,
        "endMs": 23490,
        "timestampMs": 23330,
        "confidence": 0.7431596418221792
      },
      {
        "text": " точка",
        "startMs": 23490,
        "endMs": 23870,
        "timestampMs": 23680,
        "confidence": 0.9589737951755524
      },
      {
        "text": " росы",
        "startMs": 23870,
        "endMs": 24250,
        "timestampMs": 24060,
        "confidence": 0.6710734367370605
      },
      {
        "text": " очень",
        "startMs": 24250,
        "endMs": 24650,
        "timestampMs": 24450,
        "confidence": 0.9399282932281494
      },
      {
        "text": " высокая.",
        "startMs": 24650,
        "endMs": 25330,
        "timestampMs": 24990,
        "confidence": 0.997688889503479
      }
    ]
  },
  {
    "start": 25810,
    "end": 27410,
    "words": [
      {
        "text": " Высокая",
        "startMs": 25810,
        "endMs": 26250,
        "timestampMs": 26030,
        "confidence": 0.9539392292499542
      },
      {
        "text": " вероятность",
        "startMs": 26250,
        "endMs": 26750,
        "timestampMs": 26500,
        "confidence": 0.9969707578420639
      },
      {
        "text": " тумана.",
        "startMs": 26750,
        "endMs": 27250,
        "timestampMs": 27000,
        "confidence": 0.9607871969540914
      }
    ]
  },
  {
    "start": 27970,
    "end": 30890,
    "words": [
      {
        "text": " Высокая",
        "startMs": 27970,
        "endMs": 28710,
        "timestampMs": 28340,
        "confidence": 0.7678358368575573
      },
      {
        "text": " вероятность",
        "startMs": 28710,
        "endMs": 29510,
        "timestampMs": 29110,
        "confidence": 0.9945418983697891
      },
      {
        "text": " даже",
        "startMs": 29510,
        "endMs": 30430,
        "timestampMs": 29970,
        "confidence": 0.3556792140007019
      },
      {
        "text": " того,",
        "startMs": 30430,
        "endMs": 30750,
        "timestampMs": 30590,
        "confidence": 0.9660090208053589
      }
    ]
  },
  {
    "start": 30890,
    "end": 32970,
    "words": [
      {
        "text": " что",
        "startMs": 30890,
        "endMs": 30990,
        "timestampMs": 30940,
        "confidence": 0.9911059737205505
      },
      {
        "text": " температура",
        "startMs": 30990,
        "endMs": 31530,
        "timestampMs": 31260,
        "confidence": 0.9979681571324667
      },
      {
        "text": " может",
        "startMs": 31530,
        "endMs": 31750,
        "timestampMs": 31640,
        "confidence": 0.9850766062736511
      },
      {
        "text": " упасть",
        "startMs": 31750,
        "endMs": 32170,
        "timestampMs": 31960,
        "confidence": 0.9908982813358307
      },
      {
        "text": " до",
        "startMs": 32170,
        "endMs": 32390,
        "timestampMs": 32280,
        "confidence": 0.9430482983589172
      },
      {
        "text": " нуля.",
        "startMs": 32390,
        "endMs": 32810,
        "timestampMs": 32600,
        "confidence": 0.9230427145957947
      }
    ]
  },
  {
    "start": 33830,
    "end": 36610,
    "words": [
      {
        "text": " И",
        "startMs": 33830,
        "endMs": 33890,
        "timestampMs": 33860,
        "confidence": 0.48442912101745605
      },
      {
        "text": " при",
        "startMs": 33890,
        "endMs": 34270,
        "timestampMs": 34080,
        "confidence": 0.9787266254425049
      },
      {
        "text": " этом",
        "startMs": 34270,
        "endMs": 34590,
        "timestampMs": 34430,
        "confidence": 0.9975196719169617
      },
      {
        "text": " покрытие",
        "startMs": 34590,
        "endMs": 35850,
        "timestampMs": 35220,
        "confidence": 0.9873441308736801
      },
      {
        "text": " не",
        "startMs": 35850,
        "endMs": 36070,
        "timestampMs": 35960,
        "confidence": 0.9600916504859924
      },
      {
        "text": " ляжет,",
        "startMs": 36070,
        "endMs": 36570,
        "timestampMs": 36320,
        "confidence": 0.858082910378774
      }
    ]
  },
  {
    "start": 36610,
    "end": 38150,
    "words": [
      {
        "text": " как",
        "startMs": 36610,
        "endMs": 36790,
        "timestampMs": 36700,
        "confidence": 0.9804628491401672
      },
      {
        "text": " следует.",
        "startMs": 36790,
        "endMs": 37990,
        "timestampMs": 37390,
        "confidence": 0.9872703850269318
      }
    ]
  },
  {
    "start": 38210,
    "end": 40510,
    "words": [
      {
        "text": " То",
        "startMs": 38210,
        "endMs": 38370,
        "timestampMs": 38290,
        "confidence": 0.7757046818733215
      },
      {
        "text": " есть",
        "startMs": 38370,
        "endMs": 38530,
        "timestampMs": 38450,
        "confidence": 0.9914582371711731
      },
      {
        "text": " не",
        "startMs": 38530,
        "endMs": 38690,
        "timestampMs": 38610,
        "confidence": 0.8975083827972412
      },
      {
        "text": " успеет",
        "startMs": 38690,
        "endMs": 39210,
        "timestampMs": 38950,
        "confidence": 0.9880218108495077
      },
      {
        "text": " набрать",
        "startMs": 39210,
        "endMs": 39530,
        "timestampMs": 39370,
        "confidence": 0.9018477201461792
      },
      {
        "text": " силу,",
        "startMs": 39530,
        "endMs": 40490,
        "timestampMs": 40010,
        "confidence": 0.9335045516490936
      }
    ]
  },
  {
    "start": 40510,
    "end": 40790,
    "words": [
      {
        "text": " да.",
        "startMs": 40510,
        "endMs": 40630,
        "timestampMs": 40570,
        "confidence": 0.7491729855537415
      }
    ]
  }
];
