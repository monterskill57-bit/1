import type {Page} from './Design';
export const pages2:Page[]=[
  {
    "start": 630,
    "end": 2650,
    "words": [
      {
        "text": " И",
        "startMs": 630,
        "endMs": 770,
        "timestampMs": 700,
        "confidence": 0.9542070627212524
      },
      {
        "text": " в",
        "startMs": 770,
        "endMs": 1490,
        "timestampMs": 1130,
        "confidence": 0.8124467730522156
      },
      {
        "text": " связи",
        "startMs": 1490,
        "endMs": 1670,
        "timestampMs": 1580,
        "confidence": 0.9896154403686523
      },
      {
        "text": " с",
        "startMs": 1670,
        "endMs": 1850,
        "timestampMs": 1760,
        "confidence": 0.9922014474868774
      },
      {
        "text": " этим",
        "startMs": 1850,
        "endMs": 2130,
        "timestampMs": 1990,
        "confidence": 0.9978856444358826
      },
      {
        "text": " мы",
        "startMs": 2130,
        "endMs": 2650,
        "timestampMs": 2390,
        "confidence": 0.8523375391960144
      }
    ]
  },
  {
    "start": 2650,
    "end": 5330,
    "words": [
      {
        "text": " наших",
        "startMs": 2650,
        "endMs": 3670,
        "timestampMs": 3160,
        "confidence": 0.5967199802398682
      },
      {
        "text": " клиентов,",
        "startMs": 3670,
        "endMs": 4290,
        "timestampMs": 3980,
        "confidence": 0.9945846498012543
      },
      {
        "text": " особенно",
        "startMs": 4410,
        "endMs": 4690,
        "timestampMs": 4550,
        "confidence": 0.9962531328201294
      },
      {
        "text": " постоянных",
        "startMs": 4690,
        "endMs": 5330,
        "timestampMs": 5010,
        "confidence": 0.9643439650535583
      }
    ]
  },
  {
    "start": 5330,
    "end": 7290,
    "words": [
      {
        "text": " клиентов,",
        "startMs": 5330,
        "endMs": 5790,
        "timestampMs": 5560,
        "confidence": 0.9948116540908813
      },
      {
        "text": " пытаемся",
        "startMs": 5890,
        "endMs": 6290,
        "timestampMs": 6090,
        "confidence": 0.9891429543495178
      },
      {
        "text": " убедить",
        "startMs": 6290,
        "endMs": 6790,
        "timestampMs": 6540,
        "confidence": 0.988819440205892
      },
      {
        "text": " о",
        "startMs": 6790,
        "endMs": 6990,
        "timestampMs": 6890,
        "confidence": 0.9750174880027771
      },
      {
        "text": " том,",
        "startMs": 6990,
        "endMs": 7190,
        "timestampMs": 7090,
        "confidence": 0.999757707118988
      }
    ]
  },
  {
    "start": 7290,
    "end": 9390,
    "words": [
      {
        "text": " что",
        "startMs": 7290,
        "endMs": 7530,
        "timestampMs": 7410,
        "confidence": 0.9979536533355713
      },
      {
        "text": " все",
        "startMs": 7530,
        "endMs": 8190,
        "timestampMs": 7860,
        "confidence": 0.977425754070282
      },
      {
        "text": " фасадные",
        "startMs": 8190,
        "endMs": 8670,
        "timestampMs": 8430,
        "confidence": 0.967267245054245
      },
      {
        "text": " работы",
        "startMs": 8670,
        "endMs": 8970,
        "timestampMs": 8820,
        "confidence": 0.9918727278709412
      },
      {
        "text": " необходимо",
        "startMs": 8970,
        "endMs": 9390,
        "timestampMs": 9180,
        "confidence": 0.531268835067749
      }
    ]
  },
  {
    "start": 9390,
    "end": 11690,
    "words": [
      {
        "text": " планировать",
        "startMs": 9390,
        "endMs": 10250,
        "timestampMs": 9820,
        "confidence": 0.9966313689947128
      },
      {
        "text": " на",
        "startMs": 10250,
        "endMs": 10490,
        "timestampMs": 10370,
        "confidence": 0.9920416474342346
      },
      {
        "text": " летний",
        "startMs": 10490,
        "endMs": 11030,
        "timestampMs": 10760,
        "confidence": 0.9713122248649597
      },
      {
        "text": " период.",
        "startMs": 11030,
        "endMs": 11530,
        "timestampMs": 11280,
        "confidence": 0.9989591538906097
      }
    ]
  },
  {
    "start": 12190,
    "end": 15770,
    "words": [
      {
        "text": " Поэтому",
        "startMs": 12190,
        "endMs": 12770,
        "timestampMs": 12480,
        "confidence": 0.9845799207687378
      },
      {
        "text": " уважаемые",
        "startMs": 12770,
        "endMs": 14510,
        "timestampMs": 13640,
        "confidence": 0.9042928218841553
      },
      {
        "text": " заказчики,",
        "startMs": 14510,
        "endMs": 15770,
        "timestampMs": 15140,
        "confidence": 0.9716780781745911
      }
    ]
  },
  {
    "start": 15770,
    "end": 17870,
    "words": [
      {
        "text": " уважаемые",
        "startMs": 15770,
        "endMs": 16750,
        "timestampMs": 16260,
        "confidence": 0.903627559542656
      },
      {
        "text": " новые",
        "startMs": 16750,
        "endMs": 17050,
        "timestampMs": 16900,
        "confidence": 0.714737057685852
      },
      {
        "text": " заказчики,",
        "startMs": 17050,
        "endMs": 17730,
        "timestampMs": 17390,
        "confidence": 0.7425549725691477
      }
    ]
  },
  {
    "start": 17870,
    "end": 19270,
    "words": [
      {
        "text": " да,",
        "startMs": 17870,
        "endMs": 17930,
        "timestampMs": 17900,
        "confidence": null
      },
      {
        "text": " потенциальные",
        "startMs": 18010,
        "endMs": 18510,
        "timestampMs": 18260,
        "confidence": 0.9508664757013321
      },
      {
        "text": " заказчики,",
        "startMs": 18510,
        "endMs": 19130,
        "timestampMs": 18820,
        "confidence": 0.997381587823232
      }
    ]
  },
  {
    "start": 19270,
    "end": 21650,
    "words": [
      {
        "text": " планируйте",
        "startMs": 19270,
        "endMs": 19810,
        "timestampMs": 19540,
        "confidence": 0.9901226162910461
      },
      {
        "text": " фасадные",
        "startMs": 19810,
        "endMs": 20330,
        "timestampMs": 20070,
        "confidence": 0.9564547836780548
      },
      {
        "text": " работы",
        "startMs": 20330,
        "endMs": 20650,
        "timestampMs": 20490,
        "confidence": 0.9955026507377625
      },
      {
        "text": " заблаговременно,",
        "startMs": 20650,
        "endMs": 21610,
        "timestampMs": 21130,
        "confidence": 0.8748082518577576
      }
    ]
  },
  {
    "start": 21650,
    "end": 22910,
    "words": [
      {
        "text": " чтобы",
        "startMs": 21650,
        "endMs": 21870,
        "timestampMs": 21760,
        "confidence": 0.9308474063873291
      },
      {
        "text": " не",
        "startMs": 21870,
        "endMs": 22110,
        "timestampMs": 21990,
        "confidence": 0.9691117405891418
      },
      {
        "text": " было",
        "startMs": 22110,
        "endMs": 22310,
        "timestampMs": 22210,
        "confidence": 0.997082531452179
      },
      {
        "text": " такого,",
        "startMs": 22310,
        "endMs": 22750,
        "timestampMs": 22530,
        "confidence": 0.9692918062210083
      }
    ]
  },
  {
    "start": 22950,
    "end": 25570,
    "words": [
      {
        "text": " что",
        "startMs": 22950,
        "endMs": 23050,
        "timestampMs": 23000,
        "confidence": 0.9691481590270996
      },
      {
        "text": " вы",
        "startMs": 23050,
        "endMs": 23630,
        "timestampMs": 23340,
        "confidence": 0.6225051283836365
      },
      {
        "text": " в",
        "startMs": 23630,
        "endMs": 23690,
        "timestampMs": 23660,
        "confidence": 0.957512617111206
      },
      {
        "text": " конце",
        "startMs": 23690,
        "endMs": 23890,
        "timestampMs": 23790,
        "confidence": 0.9858556389808655
      },
      {
        "text": " августа",
        "startMs": 23890,
        "endMs": 24790,
        "timestampMs": 24340,
        "confidence": 0.9367904663085938
      },
      {
        "text": " такие",
        "startMs": 24790,
        "endMs": 25570,
        "timestampMs": 25180,
        "confidence": 0.9265321493148804
      }
    ]
  },
  {
    "start": 25570,
    "end": 27930,
    "words": [
      {
        "text": " опла,",
        "startMs": 25570,
        "endMs": 26330,
        "timestampMs": 25950,
        "confidence": 0.6631277352571487
      },
      {
        "text": " а",
        "startMs": 26570,
        "endMs": 26650,
        "timestampMs": 26610,
        "confidence": 0.9851558804512024
      },
      {
        "text": " надо",
        "startMs": 26650,
        "endMs": 26810,
        "timestampMs": 26730,
        "confidence": 0.9934712648391724
      },
      {
        "text": " фасад",
        "startMs": 26810,
        "endMs": 27250,
        "timestampMs": 27030,
        "confidence": 0.9890892704327902
      },
      {
        "text": " красить.",
        "startMs": 27250,
        "endMs": 27770,
        "timestampMs": 27510,
        "confidence": 0.9780261814594269
      }
    ]
  },
  {
    "start": 28130,
    "end": 31670,
    "words": [
      {
        "text": " Ну,",
        "startMs": 28130,
        "endMs": 28170,
        "timestampMs": 28150,
        "confidence": 0.5495591163635254
      },
      {
        "text": " ни",
        "startMs": 28330,
        "endMs": 28450,
        "timestampMs": 28390,
        "confidence": 0.43712326884269714
      },
      {
        "text": " одна",
        "startMs": 28450,
        "endMs": 28790,
        "timestampMs": 28620,
        "confidence": 0.9911341071128845
      },
      {
        "text": " адекватная",
        "startMs": 28790,
        "endMs": 29850,
        "timestampMs": 29320,
        "confidence": 0.992774099111557
      },
      {
        "text": " бригада",
        "startMs": 29850,
        "endMs": 30450,
        "timestampMs": 30150,
        "confidence": 0.9689916173617045
      },
      {
        "text": " не",
        "startMs": 30450,
        "endMs": 31670,
        "timestampMs": 31060,
        "confidence": 0.9908276200294495
      }
    ]
  },
  {
    "start": 31670,
    "end": 34190,
    "words": [
      {
        "text": " будет",
        "startMs": 31670,
        "endMs": 32250,
        "timestampMs": 31960,
        "confidence": 0.9950450658798218
      },
      {
        "text": " браться",
        "startMs": 32250,
        "endMs": 33110,
        "timestampMs": 32680,
        "confidence": 0.927026242017746
      },
      {
        "text": " за",
        "startMs": 33110,
        "endMs": 33290,
        "timestampMs": 33200,
        "confidence": 0.9975646734237671
      },
      {
        "text": " эту",
        "startMs": 33290,
        "endMs": 33430,
        "timestampMs": 33360,
        "confidence": 0.9982169270515442
      },
      {
        "text": " работу",
        "startMs": 33430,
        "endMs": 33810,
        "timestampMs": 33620,
        "confidence": 0.9994712471961975
      },
      {
        "text": " в",
        "startMs": 33810,
        "endMs": 34190,
        "timestampMs": 34000,
        "confidence": 0.40999382734298706
      }
    ]
  },
  {
    "start": 34190,
    "end": 35590,
    "words": [
      {
        "text": " сентябре",
        "startMs": 34190,
        "endMs": 34550,
        "timestampMs": 34370,
        "confidence": 0.9775239944458007
      },
      {
        "text": " и",
        "startMs": 34550,
        "endMs": 34670,
        "timestampMs": 34610,
        "confidence": 0.6544522643089294
      },
      {
        "text": " в",
        "startMs": 34670,
        "endMs": 34730,
        "timestampMs": 34700,
        "confidence": 0.9664445519447327
      },
      {
        "text": " октябре",
        "startMs": 34730,
        "endMs": 35010,
        "timestampMs": 34870,
        "confidence": 0.9786037355661392
      },
      {
        "text": " месяце,",
        "startMs": 35010,
        "endMs": 35550,
        "timestampMs": 35280,
        "confidence": 0.5354478880763054
      }
    ]
  },
  {
    "start": 35590,
    "end": 38930,
    "words": [
      {
        "text": " потому",
        "startMs": 35590,
        "endMs": 35810,
        "timestampMs": 35700,
        "confidence": 0.994985818862915
      },
      {
        "text": " что",
        "startMs": 35810,
        "endMs": 36210,
        "timestampMs": 36010,
        "confidence": 0.9962471127510071
      },
      {
        "text": " качество",
        "startMs": 36210,
        "endMs": 37430,
        "timestampMs": 36820,
        "confidence": 0.9727703928947449
      },
      {
        "text": " покрытия",
        "startMs": 37430,
        "endMs": 38510,
        "timestampMs": 37970,
        "confidence": 0.9843575358390808
      },
      {
        "text": " будет",
        "startMs": 38510,
        "endMs": 38930,
        "timestampMs": 38720,
        "confidence": 0.9958897233009338
      }
    ]
  },
  {
    "start": 38930,
    "end": 40170,
    "words": [
      {
        "text": " сомнительным.",
        "startMs": 38930,
        "endMs": 40010,
        "timestampMs": 39470,
        "confidence": 0.9122533917427063
      }
    ]
  }
];
