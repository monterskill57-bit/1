import React from 'react';
import {AbsoluteFill,Img,OffthreadVideo,interpolate,useCurrentFrame,useVideoConfig,staticFile,delayRender,continueRender} from 'remotion';
import type {Caption} from '@remotion/captions';
const copper='#E5A46D';
if(typeof document!=='undefined'){
 const h=delayRender('Manrope');
 const font=new FontFace('Manrope',`url(${staticFile('Manrope.ttf')})`,{weight:'200 800'});
 font.load().then(f=>{document.fonts.add(f);continueRender(h)}).catch(()=>continueRender(h));
}
export const Shot:React.FC<{src:string;trim?:number;still?:boolean;zoom?:number;position?:string}>=({src,trim=0,still=false,zoom=1.05,position='50% 50%'})=>{
 const f=useCurrentFrame();const {durationInFrames}=useVideoConfig();
 const style:React.CSSProperties={height:'100%',width:'100%',objectFit:'cover',objectPosition:position,scale:interpolate(f,[0,durationInFrames],[zoom,zoom+.045],{extrapolateRight:'clamp'}),filter:'saturate(0.88) contrast(1.025)'};
 return <AbsoluteFill style={{overflow:'hidden',background:'#252623'}}>{still?<Img src={staticFile(src)} style={style}/>:<OffthreadVideo src={staticFile(src)} trimBefore={trim} muted style={style}/>}</AbsoluteFill>
};
export const Brand:React.FC<{part:number;duration:number}>=({part,duration})=>{
 const f=useCurrentFrame();
 return <><AbsoluteFill style={{background:'linear-gradient(180deg,rgba(13,18,17,.75) 0%,transparent 30%,transparent 51%,rgba(13,18,17,.72) 82%,rgba(13,18,17,.87) 100%)'}}/>
 <div style={{position:'absolute',top:175,left:80,right:155,display:'flex',justifyContent:'space-between',alignItems:'center',fontFamily:'Manrope',color:'white'}}>
 <div><div style={{fontWeight:800,fontSize:38,letterSpacing:5}}>TERVANA</div><div style={{fontSize:18,letterSpacing:2,marginTop:10,color:'#ddd5cd'}}>ОТДЕЛКА ДЕРЕВЯННЫХ ДОМОВ</div></div>
 <div style={{border:`1px solid ${copper}99`,padding:'12px 18px',fontSize:22,fontWeight:700,color:copper}}>ЧАСТЬ {part}</div>
 </div>
 <div style={{position:'absolute',bottom:270,left:80,right:155,height:2,background:'#ffffff25'}}><div style={{height:2,background:copper,width:`${100*Math.min(1,f/duration)}%`}}/></div>
 </>
};
export type Page={start:number;end:number;words:Caption[]};
export const WordCaptions:React.FC<{pages:Page[]}>=({pages})=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const ms=f/fps*1000;
 const p=pages.find(p=>ms>=p.start&&ms<p.end);if(!p)return null;
 return <div style={{position:'absolute',left:80,width:840,bottom:350,fontFamily:'Manrope',fontSize:51,fontWeight:700,lineHeight:1.25,color:'#fff',textAlign:'left'}}>
 <div style={{display:'inline-block',padding:'20px 26px',borderRadius:16,background:'rgba(20,25,24,.84)',boxShadow:'0 10px 35px #00000020'}}>{p.words.map((w,i)=>{
 const active=ms>=w.startMs&&ms<w.endMs; const visible=ms>=w.startMs-20;
 return <span key={i} style={{display:'inline-block',marginRight:12,scale:active&&/фасад|покрыти|качеств|планир|заблаговрем|нул|силу|сентябр|октябр|туман|росы/.test(w.text)?interpolate(ms,[w.startMs,w.startMs+Math.min(80,(w.endMs-w.startMs)/2),w.endMs],[1,1.045,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}):1,opacity:visible?1:0,color:active?copper:'white',textShadow:active?'0 0 20px #E5A46D30':undefined}}>{w.text.trim()}</span>
 })}</div></div>
};
export const Accent:React.FC<{eyebrow?:string;title:string;subtitle?:string;kind?:string}>=({eyebrow,title,subtitle,kind})=>{
 const f=useCurrentFrame(); const opacity=interpolate(f,[0,8],[0,1],{extrapolateRight:'clamp'});
 return <div style={{position:'absolute',top:470,left:80,width:840,opacity,translate:`0 ${interpolate(f,[0,12],[24,0],{extrapolateRight:'clamp'})}px`,fontFamily:'Manrope',color:'white'}}>
 <div style={{padding:'34px 36px 38px',background:'rgba(20,26,24,.90)',borderRadius:22,border:`1px solid ${copper}60`,borderTop:`3px solid ${copper}`}}>
 {eyebrow&&<div style={{fontSize:24,fontWeight:600,letterSpacing:3,color:copper,marginBottom:24}}>{eyebrow}</div>}
 <div style={{fontSize:kind==='temperature'?150:kind==='hero'?85:67,lineHeight:1.12,fontWeight:800,letterSpacing:kind==='temperature'?-5:-1.5,whiteSpace:'pre-line'}}>{title}</div>
 {subtitle&&<div style={{fontSize:34,lineHeight:1.35,color:'#e1d9d0',marginTop:24,whiteSpace:'pre-line'}}>{subtitle}</div>}
 </div></div>
};
export const Planning:React.FC=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 const items=['Оценка состояния фасада','Согласование работ','Выбор подходящего сезона'];
 return <div style={{position:'absolute',left:80,top:470,width:840,fontFamily:'Manrope',color:'white',background:'rgba(20,26,24,.91)',borderRadius:22,padding:'34px 32px',boxSizing:'border-box',border:`1px solid ${copper}55`}}>
 <div style={{fontSize:24,letterSpacing:3,color:copper,marginBottom:26}}>ПЛАНИРОВАНИЕ РАБОТ</div>
 {items.map((s,i)=><div key={s} style={{display:'flex',gap:22,alignItems:'center',padding:'20px 0',borderTop:'1px solid #ffffff20',opacity:interpolate(f,[i*fps*.8,i*fps*.8+10],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}><div style={{fontSize:28,fontWeight:700,color:copper,width:44}}>0{i+1}</div><div style={{fontSize:35,lineHeight:1.25,fontWeight:600}}>{s}</div></div>)}
 <div style={{fontSize:20,color:'#c5c8c2',marginTop:12}}>Пример этапов планирования</div>
 </div>
};
export const EndCard:React.FC<{part:number}>=({part})=>{
 const f=useCurrentFrame();
 return <AbsoluteFill style={{background:'rgba(12,19,17,.87)',fontFamily:'Manrope',color:'white',justifyContent:'center',padding:'0 100px',opacity:interpolate(f,[0,10],[0,1],{extrapolateRight:'clamp'})}}>
 <div style={{height:4,width:90,background:copper,marginBottom:36}}/>
 <div style={{fontSize:24,letterSpacing:4,color:copper,marginBottom:24}}>TERVANA / ЧАСТЬ {part}</div>
 <div style={{fontSize:part===1?82:78,fontWeight:800,lineHeight:1.14,whiteSpace:'pre-line'}}>{part===1?'ПРОДОЛЖЕНИЕ\nВ ЧАСТИ 2 →':'ПЛАНИРУЙТЕ\nФАСАДНЫЕ РАБОТЫ\nЗАРАНЕЕ'}</div>
 {part===2&&<><div style={{fontSize:42,fontWeight:800,letterSpacing:6,color:copper,marginTop:48}}>TERVANA</div><div style={{fontSize:37,lineHeight:1.4,marginTop:26,maxWidth:760}}>Напишите нам в Direct,<br/>чтобы обсудить свой проект.</div></>}
 </AbsoluteFill>
};
export const Cover:React.FC<{part:number}>=({part})=><AbsoluteFill style={{background:'#17201b',fontFamily:'Manrope',color:'white'}}>
 <Img src={staticFile(part===1?'house.jpg':'wood.jpg')} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:part===1?'35% 50%':'20% 50%'}}/>
 <AbsoluteFill style={{background:'linear-gradient(180deg,#0d151755 0%,#0d151744 25%,#0d1517ee 65%,#0d1517 100%)'}}/>
 <div style={{position:'absolute',top:200,left:90,fontSize:42,fontWeight:800,letterSpacing:6}}>TERVANA</div>
 <div style={{position:'absolute',top:800,left:90,right:140}}>
 <div style={{fontSize:28,letterSpacing:4,color:copper,marginBottom:32}}>ФАСАДНЫЕ РАБОТЫ / ЧАСТЬ {part}</div>
 <div style={{fontSize:part===1?92:82,fontWeight:800,lineHeight:1.12,letterSpacing:-2,whiteSpace:'pre-line'}}>{part===1?'Почему мы\nне красим\nфасады\nосенью?':'Почему фасадные\nработы нужно\nпланировать\nзаранее?'}</div>
 <div style={{height:4,width:96,background:copper,marginTop:42}}/>
 </div>
 <div style={{position:'absolute',bottom:290,left:90,color:'#d5d9d1',fontSize:26,letterSpacing:2}}>ОТДЕЛКА ДЕРЕВЯННЫХ ДОМОВ</div>
 </AbsoluteFill>;
