from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1]
out=p/'exports';out.mkdir(exist_ok=True)
for i in [1,2]:
 name=f'TERVANA_Fasad_Osen_Part_{i}.mp4'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'render'/name),'-vf','scale=in_range=pc:out_range=tv,format=yuv420p','-c:v','libx264','-preset','fast','-crf','16','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','copy','-movflags','+faststart',str(out/name)],check=True)
