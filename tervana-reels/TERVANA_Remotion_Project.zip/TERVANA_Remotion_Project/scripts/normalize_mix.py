from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parents[1]
for i in [1,2]:
 src=p/f'public/part{i}.wav';tmp=p/f'public/part{i}.normalized.wav'
 r=subprocess.run(['ffmpeg','-hide_banner','-i',str(src),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 m=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
 f=f"loudnorm=I=-16:TP=-1.5:LRA=9:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true"
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-af',f,'-ar','48000','-ac','2',str(tmp)],check=True)
 tmp.replace(src)
 print('Normalized mix',i,flush=True)
