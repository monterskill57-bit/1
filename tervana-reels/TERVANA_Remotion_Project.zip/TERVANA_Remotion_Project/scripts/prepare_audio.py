from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1]/'public'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'voice.m4a'),'-af','highpass=f=75,lowpass=f=14500,afftdn=nf=-28:nt=w,loudnorm=I=-16:TP=-1.5:LRA=9','-ar','48000','-ac','1',str(p/'voice_clean.wav')],check=True)
for i,start,end,prefix,duration in [(1,0,40.55,.25,43.5),(2,40.55,80.65,.4,43.9)]:
 filt=f'[0:a]atrim=start={start}:end={end},asetpts=PTS-STARTPTS,adelay={int(prefix*1000)}:all=1,apad,atrim=duration={duration}[v];[1:a]atrim=duration={duration},asetpts=PTS-STARTPTS,afade=t=in:d=1.5,afade=t=out:st={duration-2}:d=2[m];[v][m]amix=inputs=2:normalize=0,alimiter=limit=0.94:level=disabled[a]'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'voice_clean.wav'),'-i',str(p/'music.wav'),'-filter_complex',filt,'-map','[a]','-ar','48000','-ac','2',str(p/f'part{i}.wav')],check=True)
