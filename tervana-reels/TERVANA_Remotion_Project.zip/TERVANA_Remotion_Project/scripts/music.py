from pathlib import Path
import numpy as np
from scipy.io.wavfile import write
sr=32000; dur=90;n=sr*dur
x=np.zeros((n,2),dtype=np.float32)
# Original restrained ambient score: Em(add9), Cmaj7, G(add9), Dsus2.
chords=[[40,47,54,59,66],[36,43,52,59,64],[31,43,50,57,62],[38,45,52,57,64]]
for k in range(12):
 start=k*8; length=min(11,dur-start)
 if length<=0:break
 t=np.arange(int(length*sr))/sr
 env=(1-np.exp(-t/1.8))*np.exp(-np.maximum(0,t-6)/2.5)
 for j,m in enumerate(chords[k%4]):
  hz=440*2**((m-69)/12)
  a=(np.sin(2*np.pi*hz*t+0.07*np.sin(2*np.pi*.17*t))+0.18*np.sin(2*np.pi*hz*2*t))/len(chords[0])
  a*=env*.018
  for c in range(2):x[start*sr:start*sr+len(t),c]+=a*(1+(.15 if c==j%2 else -.15))
 # sparse soft mallet notes
 for j,m in enumerate(chords[k%4][2:]):
  st=start+2+j*1.8
  if st+3>=dur:continue
  tt=np.arange(sr*3)/sr;f=440*2**((m+12-69)/12)
  a=np.sin(2*np.pi*f*tt)*np.exp(-tt*2.2)*(1-np.exp(-tt*80))*.008
  for c in range(2):x[int(st*sr):int(st*sr)+len(tt),c]+=a
fade=np.minimum(np.arange(n)/sr/2,1)*np.minimum((n-np.arange(n))/sr/3,1)
x*=fade[:,None]
write(str(Path(__file__).resolve().parents[1]/'public/music.wav'),sr,(x*32767).astype('int16'))
