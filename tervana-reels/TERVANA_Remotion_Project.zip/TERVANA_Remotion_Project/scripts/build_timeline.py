import json,pathlib
p=pathlib.Path(__file__).resolve().parents[1]
w=json.load(open(p/'words_check.json'))
# Orthographic corrections only; original voice remains untouched.
r=[];i=0
while i<len(w):
 a=w[i].copy()
 if a['text'].strip()=='за' and 60700<a['startMs']<61200:
  a['text']=' заблаговременно,';a['endMs']=w[i+1]['endMs'];i+=1
 if a['startMs']==11260:a['text']=' простая.'
 if a['startMs']==40260:a['text']=' да.'
 if a['startMs']==40780:a['text']=' И'
 if a['startMs']==58020:
  r.append(dict(text=' да,',startMs=58020,endMs=58080,timestampMs=58050,confidence=None));a['startMs']=58160
 a['timestampMs']=(a['startMs']+a['endMs'])//2
 r.append(a);i+=1
json.dump(r,open(p/'words_reviewed.json','w'),ensure_ascii=False,indent=2)
for part,lo,hi,shift in [(1,0,40550,250),(2,40550,80650,-40150)]:
 words=[]
 for a in r:
  if lo<=a['startMs']<hi:
   a=a.copy()
   for k in ['startMs','endMs','timestampMs']:a[k]+=shift
   words.append(a)
 pages=[];cur=[]
 for a in words:
  if cur and (len(' '.join(x['text'].strip() for x in cur)+' '+a['text'].strip())>43 or len(cur)>=6 or a['startMs']-cur[-1]['endMs']>550):
   pages.append(dict(start=cur[0]['startMs'],end=cur[-1]['endMs']+160,words=cur));cur=[]
  cur.append(a)
  if a['text'].strip().endswith(('.', '?', '!')) or (a['text'].strip().endswith(',') and len(cur)>=3):
   pages.append(dict(start=cur[0]['startMs'],end=cur[-1]['endMs']+160,words=cur));cur=[]
 if cur:pages.append(dict(start=cur[0]['startMs'],end=cur[-1]['endMs']+180,words=cur))
 for x,y in zip(pages,pages[1:]):x['end']=min(x['end'],y['start'])
 json.dump(pages,open(p/f'captions_part{part}.json','w'),ensure_ascii=False,indent=2)
 with open(p/f'src/Captions{part}.ts','w') as f:f.write("import type {Page} from './Design';\nexport const pages"+str(part)+":Page[]="+json.dumps(pages,ensure_ascii=False,indent=2)+';\n')
 def time(ms):
  h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
 (p/f'captions_part{part}.srt').write_text('\n\n'.join(f"{j+1}\n{time(x['start'])} --> {time(x['end'])}\n"+' '.join(a['text'].strip() for a in x['words']) for j,x in enumerate(pages)),encoding='utf-8')
shots1=[(0,3.4,'1.mp4',.2,1.0,'35% 50%'),(3.4,6.6,'3.mp4',.3,1.05,'25% 50%'),(6.6,10.8,'2.mp4',0,1.0,'25% 50%'),(10.8,14,'1.mp4',3,1.12,'65% 45%'),(14,17,'wood.jpg',0,1.32,'0% 38%'),(17,20.3,'2.mp4',.8,1.04,'30% 50%'),(20.3,22.9,'4.mp4',0,1.02,'40% 45%'),(22.9,26,'3.mp4',3.4,1.08,'10% 42%'),(26,29,'1.mp4',4.6,1.13,'60% 45%'),(29,33.4,'front.jpg',0,1.13,'18% 45%'),(33.4,36.5,'3.mp4',.6,1.23,'0% 38%'),(36.5,40.9,'1.mp4',1.8,1.07,'38% 45%'),(40.9,43.5,'house.jpg',0,1.08,'40% 45%')]
shots2=[(0,3.4,'3.mp4',2.4,1.04,'25% 45%'),(3.4,6.8,'1.mp4',.3,1.09,'42% 45%'),(6.8,10.3,'wood.jpg',0,1.18,'0% 45%'),(10.3,13.6,'2.mp4',.3,1.04,'28% 45%'),(13.6,17,'3.mp4',3.2,1.1,'10% 43%'),(17,20.8,'1.mp4',3.8,1.04,'64% 45%'),(20.8,24,'4.mp4',0,1.13,'35% 44%'),(24,27.7,'front.jpg',0,1.05,'25% 45%'),(27.7,31,'3.mp4',1.3,1.25,'0% 40%'),(31,34.5,'1.mp4',.6,1.05,'40% 45%'),(34.5,37.6,'wood.jpg',0,1.33,'0% 38%'),(37.6,40.6,'2.mp4',.1,1.07,'30% 45%'),(40.6,43.9,'house.jpg',0,1.12,'35% 45%')]
head="""import React from 'react';
import {Composition,Still,Sequence,AbsoluteFill,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {Shot,Brand,WordCaptions,Accent,Planning,EndCard,Cover} from './Design';
import {pages1} from './Captions1';
import {pages2} from './Captions2';
"""
def seq(start,end,inner,name):
 return f'<Sequence name={json.dumps(name,ensure_ascii=False)} from={{{round(start*30)}}} durationInFrames={{{round(end*30)-round(start*30)}}} premountFor={{fps}}>{inner}</Sequence>\n'
code=head
for part,shots,duration in [(1,shots1,43.5),(2,shots2,43.9)]:
 code+=f'export const Part{part}=()=>{{const {{fps}}=useVideoConfig();return <AbsoluteFill style={{{{background:"#17201b"}}}}>\n'
 for j,(start,end,src,trim,zoom,pos) in enumerate(shots):
  code+=seq(start,end,f'<Shot src="{src}" trim={{{round(trim*30)}}} still={{{str(src.endswith(".jpg")).lower()}}} zoom={{{zoom}}} position="{pos}"/>',f'План {j+1} / {src}')
 code+=f'<Brand part={{{part}}} duration={{{round(duration*30)}}}/><Audio src={{staticFile("part{part}.wav")}} premountFor={{fps}}/>\n'
 if part==1:
  cards=[(0,5.2,'СЕНТЯБРЬ / ОКТЯБРЬ','Почему мы\nне красим фасады\nосенью?',None,'hero'),(11.05,14.2,'ПРИЧИНА','Нестабильная\nпогода',None,None),(20.49,21.31,'ДНЁМ','+15 °C',None,'temperature'),(21.31,22.09,'ДНЁМ','+20 °C',None,'temperature'),(22.09,23.05,'ДНЁМ','+18 °C',None,'temperature'),(23.17,25.75,'НОЧЬЮ','ТОЧКА РОСЫ',None,None),(25.81,27.8,'НОЧЬЮ','ТУМАН','Высокая вероятность',None),(28.0,33.55,'НОЧЬЮ','ДО 0 °C','Возможно резкое похолодание',None),(34.57,40.8,'НЕПОДХОДЯЩИЕ УСЛОВИЯ','РИСК ДЛЯ\nКАЧЕСТВА\nПОКРЫТИЯ',None,None)]
 else:
  cards=[(0,3.6,'ПРОДОЛЖЕНИЕ / ЧАСТЬ 2','ФАСАДНЫЕ\nРАБОТЫ ОСЕНЬЮ',None,None),(19.2,22.0,'СОВЕТ ЗАКАЗЧИКАМ','ПЛАНИРУЙТЕ\nЗАРАНЕЕ',None,None),(23.05,28.1,'КОНЕЦ АВГУСТА','«А НАДО БЫ\nФАСАД\nПОКРАСИТЬ…»',None,None),(34.2,39.95,'СЕНТЯБРЬ / ОКТЯБРЬ','КАЧЕСТВО\nПОД ВОПРОСОМ',None,None)]
 for start,end,eye,title,sub,kind in cards:
  inner='<Accent eyebrow='+json.dumps(eye,ensure_ascii=False)+' title={'+json.dumps(title,ensure_ascii=False)+'}'
  if sub:inner+=' subtitle={'+json.dumps(sub,ensure_ascii=False)+'}'
  if kind:inner+=' kind="'+kind+'"'
  inner+='/>'
  code+=seq(start,end,inner,eye+' / '+title.replace('\n',' '))
 if part==2:code+=seq(5.89,11.65,'<Planning/>','Этапы планирования')
 code+=f'<WordCaptions pages={{pages{part}}}/>\n'
 code+=seq(40.9 if part==1 else 40.6,duration,f'<EndCard part={{{part}}}/>','Финальная карточка')
 code+='</AbsoluteFill>};\n'
code+='''export const Root=()=> <>
<Composition id="Part1" component={Part1} width={1080} height={1920} fps={30} durationInFrames={1305}/>
<Composition id="Part2" component={Part2} width={1080} height={1920} fps={30} durationInFrames={1317}/>
<Still id="Cover1" component={Cover} width={1080} height={1920} defaultProps={{part:1}}/>
<Still id="Cover2" component={Cover} width={1080} height={1920} defaultProps={{part:2}}/>
</>;
'''
code=code.replace("import React from 'react';\n",'')
(p/'src/Root.tsx').write_text(code)
